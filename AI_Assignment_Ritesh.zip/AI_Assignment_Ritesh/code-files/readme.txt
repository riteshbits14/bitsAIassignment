1. Installed Webstorm2023.2.5 version
2. Created a react project.
3. Followed the video guidelines as suggested in the assignment.
4. Load the project zipped into Webstorm project folder: C:\Users\Ritesh\WebstormProjects\react-chatgpt-clone
/// As full project size is very huge, Only copying the code files. Copy the code files into respective folders. Full project will be available on github --> https://github.com/riteshbits14/bitsAIassignment

5. Running the frontend: npm run start:frontend
6. Running the backend: npm run start:backend
7. It will open the local host link --> http://localhost:3000/
8. Feel Free to browse the chat GPT bot and get your queries answered.
9. Drive Link for video: Explaining the working of BOT --> https://drive.google.com/file/d/1Mvq_00sRsWOQsKlYM26X_36sMBRDV-55/view?usp=sharing
-------------------------------------

Ritesh Agarwal
2022MT93672
AI Assignment
02-Dec-2023